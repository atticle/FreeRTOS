// uart_retarget.h
#ifndef UART_RETARGET_H
#define UART_RETARGET_H
#include "main.h"

void UART_Retarget_Init(UART_HandleTypeDef *huart);
int safe_printf(const char *format, ...);

#endif