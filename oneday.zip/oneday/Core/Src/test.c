int x = 10;
int y;

int foo(int x)
{
    int y;
    return y + x;
}

void boo()
{
    int k = foo(10);
}