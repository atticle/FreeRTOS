// uart_retarget.c
#include "uart_retarget.h"
#include <stdio.h>
#include <stdarg.h>
#include "cmsis_os2.h"

#define RX_BUFFER_SIZE 128
#define TX_BUFFER_SIZE 256

typedef struct {
    uint8_t buffer[RX_BUFFER_SIZE];
    volatile uint16_t head;
    volatile uint16_t tail;
} RingBuffer;

static RingBuffer rx_ring = { {0}, 0, 0 };
static uint8_t rx_data;
static UART_HandleTypeDef *target_huart = NULL;

static osMutexId_t tx_mutex = NULL;      
static osSemaphoreId_t rx_sem = NULL;    

void UART_Retarget_Init(UART_HandleTypeDef *huart)
{
    target_huart = huart;
    tx_mutex = osMutexNew(NULL);
    rx_sem = osSemaphoreNew(RX_BUFFER_SIZE, 0, NULL);

    HAL_UART_Receive_IT(target_huart, &rx_data, 1);
}

int __io_putchar(int ch)
{
    if (target_huart != NULL)
    {
        HAL_UART_Transmit(target_huart, (uint8_t *)&ch, 1, HAL_MAX_DELAY);
    }
    return ch;
}

int safe_printf(const char *format, ...)
{
    static char tx_buffer[256]; 
    va_list args;
    int length = 0;

    if (osKernelGetState() == osKernelRunning && tx_mutex != NULL) {
        osMutexAcquire(tx_mutex, osWaitForever);
    }

    va_start(args, format);
    length = vsnprintf(tx_buffer, sizeof(tx_buffer), format, args);
    va_end(args);

    if (length > 0 && target_huart != NULL)
    {
        HAL_UART_Transmit(target_huart, (uint8_t *)tx_buffer, length, HAL_MAX_DELAY);
    }

    if (osKernelGetState() == osKernelRunning && tx_mutex != NULL) {
        osMutexRelease(tx_mutex);
    }

    return length;
}


int _read(int file, char *ptr, int len)
{
    int DataIdx;
    
    if (osKernelGetState() != osKernelRunning || rx_sem == NULL) {
        for (DataIdx = 0; DataIdx < len; DataIdx++) {
            while (rx_ring.head == rx_ring.tail);
            *ptr = rx_ring.buffer[rx_ring.tail];
            rx_ring.tail = (rx_ring.tail + 1) % RX_BUFFER_SIZE;
            if (*ptr == '\n' || *ptr == '\r') { *ptr = '\n'; return DataIdx + 1; }
            ptr++;
        }
        return len;
    }

    for (DataIdx = 0; DataIdx < len; DataIdx++)
    {
        osSemaphoreAcquire(rx_sem, osWaitForever);

        *ptr = rx_ring.buffer[rx_ring.tail];
        rx_ring.tail = (rx_ring.tail + 1) % RX_BUFFER_SIZE;

        if (*ptr == '\n' || *ptr == '\r')
        {
            *ptr = '\n';
            return DataIdx + 1;
        }
        ptr++;
    }
    return len;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if (target_huart != NULL && huart->Instance == target_huart->Instance)
    {
        uint16_t next_head = (rx_ring.head + 1) % RX_BUFFER_SIZE;
        
        if (next_head != rx_ring.tail)
        {
            rx_ring.buffer[rx_ring.head] = rx_data;
            rx_ring.head = next_head;
            
            if (osKernelGetState() == osKernelRunning && rx_sem != NULL) {
                osSemaphoreRelease(rx_sem);
            }
        }
        
        HAL_UART_Receive_IT(target_huart, &rx_data, 1);
    }
}